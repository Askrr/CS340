from pymongo import MongoClient

class CRUDopps(object):
    def __init__(self, username, password):
        #initialize the MongoClient and set up the connection
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32553
        DB = 'AAC'
        COL = 'animals'
        
        self.client = MongoClient(f'mongodb://{username}:{password}@{HOST}:{PORT}')
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

    def create(self, data):
        #2-a: A method that inserts a document into a specified MongoDB database and collection
        if data is not None:
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
        else:
                raise Exception("nothing to save because the data parameter is empty")
        
    def read(self, query):
        #2-b: A method that queries for docs from a specified MongoDB database and collection
        cursor = self.collection.find(query)
        result = list(cursor)
        return result
    
    def update(self, query, update_data):
        #2-c: A Method that queries for and changes documents from a specified MongoD database and collection
        if query and update_data:
            result=self.collection.update_many(query, update_data)
            return result.modified_count
        else:
            raise Exception("Invalid query or update_data parameters")
            
    def delete(self, query):
        #2-d: A Method that queries for and removes documents from a specified MongoDB database and collection
        if query:
            result=self.collection.delete_many(query)
            return result.deleted_count
        else:
            raise Exception("Invalid query parameter")
    
